

export class sales {
    id: number;
    name: String;
    department: String;
    joining_date: Date;
    status: String;



}