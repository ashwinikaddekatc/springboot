import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-new',
  templateUrl: './sales-new.component.html',
  styleUrls: ['./sales-new.component.scss']
})
export class SalesNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
