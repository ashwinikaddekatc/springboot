import { Audit } from "src/app/models/Audit";



export class Department extends Audit {
    public Did:number;
    public Dname:String;
    public  Dhead:String;
    public Dcontact:number;
    public No_ofEmp:number;

   
   

}