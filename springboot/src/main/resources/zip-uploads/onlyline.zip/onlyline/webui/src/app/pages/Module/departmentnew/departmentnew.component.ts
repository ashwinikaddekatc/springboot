import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-new',
  templateUrl: './department-new.component.html',
  styleUrls: ['./department-new.component.scss']
})
export class DepartmentNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
