
import { Audit } from "src/app/models/Audit";

export class sales extends Audit {
    id: number;
   
   
   
   



}