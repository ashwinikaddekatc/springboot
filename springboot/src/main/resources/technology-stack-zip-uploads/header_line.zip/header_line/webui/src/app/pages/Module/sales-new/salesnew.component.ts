import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-new',
  templateUrl: './salesnew.component.html',
  styleUrls: ['./salesnew.component.scss']
})
export class SalesNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
