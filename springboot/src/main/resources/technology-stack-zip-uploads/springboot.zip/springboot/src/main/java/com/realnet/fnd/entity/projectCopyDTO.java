package com.realnet.fnd.entity;

import lombok.Data;

@Data
public class projectCopyDTO {
	private int from_projectId;
	private String to_projectName;
	private String to_tech_stack;

	
}
