package com.realnet.comm.service;

import com.realnet.comm.entity.MultifieldForm;

public interface multifieldservice {

//	getall();
	MultifieldForm addfield(MultifieldForm multifield);
}
