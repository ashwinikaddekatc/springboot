package com.realnet.codeextractor.entity;

import lombok.Data;

@Data
public class ActiveTechStack_DTO {
	private int id;
	private String Name;
	
//	public Integer getId() {
//		return id;
//	}
//	public void setId(Integer id) {
//		this.id = id;
//	}
//	public Integer getName() {
//		return Name;
//	}
//	public void setName(Integer name) {
//		Name = name;
//	}
	
}
