import { Component, OnInit } from '@angular/core';

@Component({
	selector: 's-dashboard-pg',
	templateUrl: './dashboard.component.html',
    styleUrls: [ './dashboard.scss'],
})

export class DashboardComponent {
  constructor( ) { }
}
