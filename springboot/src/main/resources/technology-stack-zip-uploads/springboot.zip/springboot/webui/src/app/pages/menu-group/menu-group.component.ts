import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-menu-group',
  templateUrl: './menu-group.component.html',
  styleUrls: ['./menu-group.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class MenuGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
