export class salesperson{
    public Pname:String;
}