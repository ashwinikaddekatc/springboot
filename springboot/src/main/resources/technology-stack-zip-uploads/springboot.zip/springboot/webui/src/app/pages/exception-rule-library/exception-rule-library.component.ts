import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-exception-rule-library',
  templateUrl: './exception-rule-library.component.html',
  styleUrls: ['./exception-rule-library.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ExceptionRuleLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
