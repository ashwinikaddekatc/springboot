import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-org-user',
  templateUrl: './org-user.component.html',
  styleUrls: ['./org-user.component.scss'],
})
export class OrgUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
