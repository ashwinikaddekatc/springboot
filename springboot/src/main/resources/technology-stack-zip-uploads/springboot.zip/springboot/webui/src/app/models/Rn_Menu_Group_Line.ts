export class Rn_Menu_Group_Line {
    public id: number;
    public name: string;
    public active: boolean;
    public start_date: Date;
    public end_date: Date;
    public menu_id: number;
    public seq: number;
    public type: string;
}