import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-menu-register',
	templateUrl: './menu-register.component.html',
    styleUrls: [ './menu-register.scss'],
})
export class MenuRegisterComponent implements OnInit {
    constructor(){}
    ngOnInit() {}
}
