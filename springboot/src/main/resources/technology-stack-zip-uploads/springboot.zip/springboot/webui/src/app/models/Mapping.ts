export interface Mapping {
  label: string;
  value: string;
}
