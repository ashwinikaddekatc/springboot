export interface FileData {
    id: number;
    text: string;
    /* public id: number;
    public text: string; */
    /* constructor(id: number, text: string) {
        this.id = id;
        this.text = text;
    } */
}