import { Audit } from "./Audit";

export class DynamicForm extends Audit {
    public id: number;
    public form_id: number;
    public form_version: number;
    public comp1: string;
    public comp2: string;
    public comp3: string;
    public comp4: string;
    public comp5: string;
    public comp6: string;
    public comp7: string;
    public comp8: string;
    public comp9: string;
    public comp10: string;
    public comp11: string;
    public comp12: string;
    public comp13: string;
    public comp14: string;
    public comp15: string;
    public comp16: string;
    public comp17: string;
    public comp18: string;
    public comp19: string;
    public comp20: string;
    public comp21: string;
    public comp22: string;
    public comp23: string;
    public comp24: string;
    public comp25: string;
    public comp_l26: string;
    public comp_l27: string;
    public comp_l28: string;
    public comp_l29: string;
    public comp_l30: string;
}