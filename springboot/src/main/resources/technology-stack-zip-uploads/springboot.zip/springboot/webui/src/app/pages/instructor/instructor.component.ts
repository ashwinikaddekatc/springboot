import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'instructor',
	templateUrl: './instructor.component.html',
    styleUrls: [ './instructor.scss'],
})
export class InstructorComponent implements OnInit {
    constructor(){}
    ngOnInit() {}
}
