export class FileList {
    public id: number;
    public fileName: string;
    /* constructor(id: number, fileName: string) {
        this.id = id;
        this.fileName = fileName;
    } */
}