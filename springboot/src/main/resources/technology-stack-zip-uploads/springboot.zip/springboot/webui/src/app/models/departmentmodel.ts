
export class Department{
    public Did:number;
    public Dname:String;
    public  Dhead:String;
    public Dcontact:number;
    public No_ofEmp:number;

}