package com.realnet.fnd.model;

import java.sql.Date;

public class Rn_News_Login {

	
	private String news_title;
	private String news_url;
	public String getNews_title() {
		return news_title;
	}
	public void setNews_title(String news_title) {
		this.news_title = news_title;
	}
	public String getNews_url() {
		return news_url;
	}
	public void setNews_url(String news_url) {
		this.news_url = news_url;
	}
	
	
}
