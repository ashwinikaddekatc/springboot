package com.realnet.fnd.model;

public class Rn_Failure_Code_Chart {
	
	String failure_code;
	int failure_amount;
	int failure_number;
	public String getFailure_code() {
		return failure_code;
	}
	public void setFailure_code(String failure_code) {
		this.failure_code = failure_code;
	}
	public int getFailure_amount() {
		return failure_amount;
	}
	public void setFailure_amount(int failure_amount) {
		this.failure_amount = failure_amount;
	}
	public int getFailure_number() {
		return failure_number;
	}
	public void setFailure_number(int failure_number) {
		this.failure_number = failure_number;
	}
	
	

}
