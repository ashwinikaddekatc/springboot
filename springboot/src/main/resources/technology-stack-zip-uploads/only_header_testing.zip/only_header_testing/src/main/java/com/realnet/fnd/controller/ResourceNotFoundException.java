package com.realnet.fnd.controller;

public class ResourceNotFoundException extends RuntimeException {

}
