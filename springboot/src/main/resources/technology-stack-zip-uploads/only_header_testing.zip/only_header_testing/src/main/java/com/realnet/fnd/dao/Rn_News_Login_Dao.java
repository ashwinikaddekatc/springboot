package com.realnet.fnd.dao;

import java.util.List;

import com.realnet.fnd.model.Rn_News_Login;

public interface Rn_News_Login_Dao {
	
public List<Rn_News_Login> DashbordApprover_List();
	

}