package com.realnet.fnd.model;

public class Rn_User_Access_Reportist {

	int	report_group_header_id;
	String report_name;
	
	public int getReport_group_header_id() {
		return report_group_header_id;
	}
	public void setReport_group_header_id(int report_group_header_id) {
		this.report_group_header_id = report_group_header_id;
	}
	public String getReport_name() {
		return report_name;
	}
	public void setReport_name(String report_name) {
		this.report_name = report_name;
	}
	
	
	
}
