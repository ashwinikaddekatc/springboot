tAutocomplete
=============

Autocomplete Table is a jQuery plugin that provides suggestions from a multi-column table in a dropdown list while the visitors type into the input field.<br/><br/>
Complete details and demo is available at http://vyasrao.github.io/tAutocomplete/

New releases<br/>
1. Delay search result<br/>
2. Highlight search word among result<br/>
3. Hide/ show columns<br/>
4. Display complete details on the selected row.
