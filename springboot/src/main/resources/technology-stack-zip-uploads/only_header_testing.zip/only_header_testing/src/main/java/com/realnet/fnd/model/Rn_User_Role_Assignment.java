package com.realnet.fnd.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "RN_USER_ROLE_ASSIGNMENTS_T")
public class Rn_User_Role_Assignment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "course_seq")
	@SequenceGenerator(name = "course_seq", sequenceName = "KOEL_USER_ROLE_ASSIGNMENT_S", allocationSize = 1)
	
	@Column(name = "USER_ROLE_ASSIGNMENT_ID")
	private int user_role_assignment_id;
	
	@Column(name = "USER_ID")
	private int user_id;
	
	@Column(name = "ROLE")
	private String role;
	
	@Column(name = "ENABLE_FLAG")
	private String enable_flag;
	
	@Column(name = "END_DATE")
	private Date end_date;
	

	
	@Column(name = "CREATED_BY")
	private int created_by;

	@DateTimeFormat(pattern = "dd/mm/yyyy")
	@Column(name = "CREATION_DATE" , updatable = false)
	private Date creation_date= new java.sql.Date(new java.util.Date().getTime());

	@Column(name = "LAST_UPDATED_BY")
	private int last_updated_by;

	@DateTimeFormat(pattern = "dd/mm/yyyy")
	@Column(name = "LAST_UPDATE_DATE" , updatable = true)
	private Date last_update_date= new java.sql.Date(new java.util.Date().getTime());



	public int getUser_role_assignment_id() {
		return user_role_assignment_id;
	}

	public void setUser_role_assignment_id(int user_role_assignment_id) {
		this.user_role_assignment_id = user_role_assignment_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEnable_flag() {
		return enable_flag;
	}

	public void setEnable_flag(String enable_flag) {
		this.enable_flag = enable_flag;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public int getLast_updated_by() {
		return last_updated_by;
	}

	public void setLast_updated_by(int last_updated_by) {
		this.last_updated_by = last_updated_by;
	}

	public Date getLast_update_date() {
		return last_update_date;
	}

	public void setLast_update_date(Date last_update_date) {
		this.last_update_date = last_update_date;
	}
	
	
}
