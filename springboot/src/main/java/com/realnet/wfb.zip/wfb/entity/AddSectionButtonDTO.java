package com.realnet.wfb.entity;

import lombok.Data;

@Data
public class AddSectionButtonDTO {
	String type;
}
