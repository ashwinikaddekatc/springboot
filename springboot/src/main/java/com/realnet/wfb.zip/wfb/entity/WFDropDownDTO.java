package com.realnet.wfb.entity;

import lombok.Data;

@Data
public class WFDropDownDTO {
	private int id;
	private String uiName;
}
