export class Extension {
    public extn1: string;
    public extn2: string;
    public extn3: string;
    public extn4: string;
    public extn5: string;
    
    public extn6: string;
    public extn7: string;
    public extn8: string;
    public extn9: string;
    public extn10: string;

    public extn11: string;
    public extn12: string;
    public extn13: string;
    public extn14: string;
    public extn15: string;
}