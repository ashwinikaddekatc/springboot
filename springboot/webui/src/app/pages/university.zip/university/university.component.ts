import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'university',
	templateUrl: './university.component.html',
    styleUrls: [ './university.scss'],
})
export class UniversityComponent implements OnInit {
    constructor(){}
    ngOnInit() {}
}
